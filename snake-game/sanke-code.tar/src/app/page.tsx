'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Play,
  RotateCcw,
  Pause,
  Trophy,
  Apple,
} from 'lucide-react'
import { cn } from '@/lib/utils'

type Point = { x: number; y: number }
type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT'
type GameState = 'IDLE' | 'PLAYING' | 'PAUSED' | 'GAMEOVER'
type Difficulty = 'EASY' | 'NORMAL' | 'HARD'

const GRID_SIZE = 20
const CELL_PX = 24
const BOARD_PX = GRID_SIZE * CELL_PX

const DIFFICULTY_SPEED: Record<Difficulty, number> = {
  EASY: 180,
  NORMAL: 120,
  HARD: 80,
}

const DIRECTION_VECTORS: Record<Direction, Point> = {
  UP: { x: 0, y: -1 },
  DOWN: { x: 0, y: 1 },
  LEFT: { x: -1, y: 0 },
  RIGHT: { x: 1, y: 0 },
}

const OPPOSITE_DIRECTION: Record<Direction, Direction> = {
  UP: 'DOWN',
  DOWN: 'UP',
  LEFT: 'RIGHT',
  RIGHT: 'LEFT',
}

const SNAKE_BODY = '#10b981'
const SNAKE_HEAD = '#059669'
const SNAKE_BORDER = '#047857'
const FOOD_COLOR = '#ef4444'
const FOOD_INNER = '#fca5a5'
const BOARD_BG = '#f8fafc'
const GRID_LINE = '#e2e8f0'

const INITIAL_SNAKE: Point[] = [
  { x: 10, y: 10 },
  { x: 9, y: 10 },
  { x: 8, y: 10 },
]

function randomFood(snake: Point[]): Point {
  const occupied = new Set(snake.map((p) => `${p.x},${p.y}`))
  let next: Point
  do {
    next = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    }
  } while (occupied.has(`${next.x},${next.y}`))
  return next
}

function pointsEqual(a: Point, b: Point) {
  return a.x === b.x && a.y === b.y
}

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE)
  const [food, setFood] = useState<Point>(() => randomFood(INITIAL_SNAKE))
  const [direction, setDirection] = useState<Direction>('RIGHT')
  const [gameState, setGameState] = useState<GameState>('IDLE')
  const [score, setScore] = useState(0)
  const [bestScore, setBestScore] = useState(0)
  const [difficulty, setDifficulty] = useState<Difficulty>('NORMAL')

  // Mutable refs for the game loop so we always read latest state without
  // re-creating the interval on every state change.
  const directionRef = useRef<Direction>(direction)
  const nextDirectionRef = useRef<Direction>(direction)
  const snakeRef = useRef<Point[]>(snake)
  const foodRef = useRef<Point>(food)
  const gameStateRef = useRef<GameState>(gameState)

  useEffect(() => {
    directionRef.current = direction
  }, [direction])
  useEffect(() => {
    snakeRef.current = snake
  }, [snake])
  useEffect(() => {
    foodRef.current = food
  }, [food])
  useEffect(() => {
    gameStateRef.current = gameState
  }, [gameState])

  // Load best score from local storage.
  useEffect(() => {
    const stored = window.localStorage.getItem('snake-best-score')
    if (stored) {
      const parsed = Number.parseInt(stored, 10)
      // eslint-disable-next-line react-hooks/set-state-in-effect
      if (!Number.isNaN(parsed)) setBestScore(parsed)
    }
  }, [])

  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // background
    ctx.fillStyle = BOARD_BG
    ctx.fillRect(0, 0, BOARD_PX, BOARD_PX)

    // grid lines
    ctx.strokeStyle = GRID_LINE
    ctx.lineWidth = 1
    for (let i = 1; i < GRID_SIZE; i++) {
      ctx.beginPath()
      ctx.moveTo(i * CELL_PX, 0)
      ctx.lineTo(i * CELL_PX, BOARD_PX)
      ctx.stroke()
      ctx.beginPath()
      ctx.moveTo(0, i * CELL_PX)
      ctx.lineTo(BOARD_PX, i * CELL_PX)
      ctx.stroke()
    }

    // food (rounded square with a little highlight)
    const fx = foodRef.current.x * CELL_PX
    const fy = foodRef.current.y * CELL_PX
    const pad = 3
    ctx.fillStyle = FOOD_COLOR
    roundRect(ctx, fx + pad, fy + pad, CELL_PX - pad * 2, CELL_PX - pad * 2, 6)
    ctx.fill()
    ctx.fillStyle = FOOD_INNER
    ctx.beginPath()
    ctx.arc(fx + CELL_PX / 2 - 3, fy + CELL_PX / 2 - 3, 2.5, 0, Math.PI * 2)
    ctx.fill()

    // snake
    const body = snakeRef.current
    body.forEach((seg, idx) => {
      const x = seg.x * CELL_PX
      const y = seg.y * CELL_PX
      const isHead = idx === 0
      ctx.fillStyle = isHead ? SNAKE_HEAD : SNAKE_BODY
      ctx.strokeStyle = SNAKE_BORDER
      ctx.lineWidth = 1
      roundRect(ctx, x + 1, y + 1, CELL_PX - 2, CELL_PX - 2, isHead ? 7 : 5)
      ctx.fill()
      ctx.stroke()

      if (isHead) {
        // draw eyes that follow direction
        const dir = directionRef.current
        ctx.fillStyle = '#ffffff'
        const eyeR = 2.5
        let e1: Point, e2: Point
        const cx = x + CELL_PX / 2
        const cy = y + CELL_PX / 2
        if (dir === 'LEFT') {
          e1 = { x: cx - 5, y: cy - 4 }
          e2 = { x: cx - 5, y: cy + 4 }
        } else if (dir === 'RIGHT') {
          e1 = { x: cx + 5, y: cy - 4 }
          e2 = { x: cx + 5, y: cy + 4 }
        } else if (dir === 'UP') {
          e1 = { x: cx - 4, y: cy - 5 }
          e2 = { x: cx + 4, y: cy - 5 }
        } else {
          e1 = { x: cx - 4, y: cy + 5 }
          e2 = { x: cx + 4, y: cy + 5 }
        }
        ctx.beginPath()
        ctx.arc(e1.x, e1.y, eyeR, 0, Math.PI * 2)
        ctx.fill()
        ctx.beginPath()
        ctx.arc(e2.x, e2.y, eyeR, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#0f172a'
        ctx.beginPath()
        ctx.arc(e1.x, e1.y, 1.2, 0, Math.PI * 2)
        ctx.fill()
        ctx.beginPath()
        ctx.arc(e2.x, e2.y, 1.2, 0, Math.PI * 2)
        ctx.fill()
      }
    })
  }, [])

  const endGame = useCallback(() => {
    setGameState('GAMEOVER')
    gameStateRef.current = 'GAMEOVER'
  }, [])

  // Game tick loop driven by setInterval.
  useEffect(() => {
    const id = window.setInterval(() => {
      if (gameStateRef.current !== 'PLAYING') {
        // Still redraw when paused/idle to keep the canvas in sync.
        draw()
        return
      }

      const currentDir = nextDirectionRef.current
      directionRef.current = currentDir
      setDirection(currentDir)

      const vec = DIRECTION_VECTORS[currentDir]
      const body = snakeRef.current
      const head = body[0]
      const newHead: Point = { x: head.x + vec.x, y: head.y + vec.y }

      // wall collision
      if (
        newHead.x < 0 ||
        newHead.x >= GRID_SIZE ||
        newHead.y < 0 ||
        newHead.y >= GRID_SIZE
      ) {
        endGame()
        return
      }

      const ateFood = pointsEqual(newHead, foodRef.current)
      // new body (without tail if not eating food)
      const newBody = ateFood ? [newHead, ...body] : [newHead, ...body.slice(0, -1)]

      // self collision (check against new body excluding the new head)
      for (let i = 1; i < newBody.length; i++) {
        if (pointsEqual(newBody[i], newHead)) {
          endGame()
          return
        }
      }

      snakeRef.current = newBody
      setSnake(newBody)

      if (ateFood) {
        const newScore = score + 1
        setScore(newScore)
        if (newScore > bestScore) {
          setBestScore(newScore)
          window.localStorage.setItem('snake-best-score', String(newScore))
        }
        const nextFood = randomFood(newBody)
        foodRef.current = nextFood
        setFood(nextFood)
      }
    }, DIFFICULTY_SPEED[difficulty])

    return () => window.clearInterval(id)
  }, [difficulty, draw, score, bestScore, endGame])

  // Initial draw + redraw whenever snake/food/score/direction change.
  useEffect(() => {
    draw()
  }, [snake, food, direction, gameState, draw])

  const startGame = useCallback(() => {
    const freshSnake = INITIAL_SNAKE.map((p) => ({ ...p }))
    const freshFood = randomFood(freshSnake)
    snakeRef.current = freshSnake
    foodRef.current = freshFood
    nextDirectionRef.current = 'RIGHT'
    directionRef.current = 'RIGHT'
    setSnake(freshSnake)
    setFood(freshFood)
    setDirection('RIGHT')
    setScore(0)
    setGameState('PLAYING')
    gameStateRef.current = 'PLAYING'
  }, [])

  const pauseGame = useCallback(() => {
    if (gameStateRef.current === 'PLAYING') {
      setGameState('PAUSED')
      gameStateRef.current = 'PAUSED'
    } else if (gameStateRef.current === 'PAUSED') {
      setGameState('PLAYING')
      gameStateRef.current = 'PLAYING'
    }
  }, [])

  const restartGame = useCallback(() => {
    startGame()
  }, [startGame])

  const setNextDirection = useCallback((dir: Direction) => {
    // ignore reversal into self
    if (OPPOSITE_DIRECTION[dir] === directionRef.current) return
    nextDirectionRef.current = dir
  }, [])

  // Keyboard controls
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const key = e.key
      let dir: Direction | null = null
      if (key === 'ArrowUp' || key === 'w' || key === 'W') dir = 'UP'
      else if (key === 'ArrowDown' || key === 's' || key === 'S') dir = 'DOWN'
      else if (key === 'ArrowLeft' || key === 'a' || key === 'A') dir = 'LEFT'
      else if (key === 'ArrowRight' || key === 'd' || key === 'D') dir = 'RIGHT'
      else if (key === ' ') {
        e.preventDefault()
        if (gameStateRef.current === 'IDLE' || gameStateRef.current === 'GAMEOVER') {
          startGame()
        } else {
          pauseGame()
        }
        return
      }
      if (dir) {
        e.preventDefault()
        if (gameStateRef.current === 'PLAYING') {
          setNextDirection(dir)
        } else if (gameStateRef.current === 'IDLE' || gameStateRef.current === 'GAMEOVER') {
          // Allow arrow keys to also start the game
          startGame()
          nextDirectionRef.current = dir
          directionRef.current = dir
        }
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [startGame, pauseGame, setNextDirection])

  const statusText = {
    IDLE: '准备开始',
    PLAYING: '游戏中',
    PAUSED: '已暂停',
    GAMEOVER: '游戏结束',
  }[gameState]

  const statusColor = {
    IDLE: 'bg-slate-100 text-slate-700',
    PLAYING: 'bg-emerald-100 text-emerald-700',
    PAUSED: 'bg-amber-100 text-amber-700',
    GAMEOVER: 'bg-rose-100 text-rose-700',
  }[gameState]

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-50 via-emerald-50/40 to-slate-100 px-4 py-8">
      <div className="mx-auto flex max-w-5xl flex-col items-center gap-6">
        {/* Title */}
        <header className="flex w-full max-w-md flex-col items-center text-center">
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500 text-white shadow-lg shadow-emerald-500/30">
              <Apple className="h-5 w-5" />
            </div>
            <h1 className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-3xl font-bold tracking-tight text-transparent">
              贪吃蛇
            </h1>
          </div>
          <p className="mt-1 text-sm text-slate-500">
            方向键 / WASD 控制移动，空格暂停
          </p>
        </header>

        <div className="flex w-full max-w-md flex-col gap-4 lg:flex-row lg:items-start lg:justify-center">
          {/* Stats column */}
          <Card className="flex-1 border-emerald-100/50 bg-white/70 shadow-sm backdrop-blur lg:w-56">
            <CardContent className="flex flex-col gap-3 p-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">当前分数</span>
                <span className="text-2xl font-bold text-emerald-600 tabular-nums">
                  {score}
                </span>
              </div>
              <div className="h-px bg-slate-100" />
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">蛇身长度</span>
                <span className="text-lg font-semibold text-slate-700 tabular-nums">
                  {snake.length}
                </span>
              </div>
              <div className="h-px bg-slate-100" />
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-xs font-medium text-slate-500">
                  <Trophy className="h-3.5 w-3.5 text-amber-500" />
                  最高分
                </span>
                <span className="text-lg font-semibold text-amber-600 tabular-nums">
                  {bestScore}
                </span>
              </div>
              <div className="h-px bg-slate-100" />
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">难度</span>
                <Select
                  value={difficulty}
                  onValueChange={(v) => setDifficulty(v as Difficulty)}
                  disabled={gameState === 'PLAYING'}
                >
                  <SelectTrigger className="h-8 w-28">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="EASY">简单</SelectItem>
                    <SelectItem value="NORMAL">普通</SelectItem>
                    <SelectItem value="HARD">困难</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Board column */}
          <Card className="border-emerald-100/50 bg-white/80 shadow-lg backdrop-blur">
            <CardContent className="p-4">
              <div className="mb-3 flex items-center justify-between">
                <Badge className={cn('rounded-full border-0', statusColor)}>
                  {statusText}
                </Badge>
                <span className="text-xs text-slate-400">20 × 20</span>
              </div>
              <div
                className="relative aspect-square w-full max-w-[480px] overflow-hidden rounded-xl ring-1 ring-slate-200"
              >
                <canvas
                  ref={canvasRef}
                  width={BOARD_PX}
                  height={BOARD_PX}
                  className="block h-full w-full"
                />
                {/* Overlays for non-playing states */}
                {gameState !== 'PLAYING' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-slate-900/55 backdrop-blur-sm">
                    {gameState === 'IDLE' && (
                      <>
                        <p className="text-lg font-semibold text-white">准备开始</p>
                        <p className="text-xs text-slate-200">按方向键或下方按钮开始</p>
                      </>
                    )}
                    {gameState === 'PAUSED' && (
                      <>
                        <Pause className="h-8 w-8 text-white" />
                        <p className="text-lg font-semibold text-white">已暂停</p>
                        <p className="text-xs text-slate-200">按空格或继续按钮恢复</p>
                      </>
                    )}
                    {gameState === 'GAMEOVER' && (
                      <>
                        <p className="text-2xl font-bold text-white">游戏结束</p>
                        <div className="flex flex-col items-center gap-1 text-sm text-slate-200">
                          <span>本局得分</span>
                          <span className="text-2xl font-bold text-emerald-300">
                            {score}
                          </span>
                          {score >= bestScore && score > 0 && (
                            <span className="mt-1 rounded-full bg-amber-400/90 px-3 py-0.5 text-xs font-medium text-amber-950">
                              新纪录！
                            </span>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Control buttons */}
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {(gameState === 'IDLE' || gameState === 'GAMEOVER') && (
                  <Button
                    onClick={startGame}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Play className="mr-1.5 h-4 w-4" />
                    {gameState === 'GAMEOVER' ? '再玩一次' : '开始游戏'}
                  </Button>
                )}
                {gameState === 'PLAYING' && (
                  <Button onClick={pauseGame} variant="outline">
                    <Pause className="mr-1.5 h-4 w-4" />
                    暂停
                  </Button>
                )}
                {gameState === 'PAUSED' && (
                  <Button
                    onClick={pauseGame}
                    className="bg-emerald-600 hover:bg-emerald-700"
                  >
                    <Play className="mr-1.5 h-4 w-4" />
                    继续
                  </Button>
                )}
                {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
                  <Button onClick={restartGame} variant="outline">
                    <RotateCcw className="mr-1.5 h-4 w-4" />
                    重新开始
                  </Button>
                )}
                {(gameState === 'IDLE' || gameState === 'GAMEOVER') && (
                  <Button
                    onClick={restartGame}
                    variant="outline"
                    disabled={gameState === 'IDLE'}
                  >
                    <RotateCcw className="mr-1.5 h-4 w-4" />
                    重新开始
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Mobile touch D-pad */}
        <div className="flex flex-col items-center gap-2 lg:hidden">
          <DPadButton
            onPress={() => {
              if (gameState === 'PLAYING') setNextDirection('UP')
              else if (gameState === 'IDLE' || gameState === 'GAMEOVER') {
                startGame()
                nextDirectionRef.current = 'UP'
                directionRef.current = 'UP'
              }
            }}
            label="上"
          >
            <ArrowUp className="h-6 w-6" />
          </DPadButton>
          <div className="flex gap-2">
            <DPadButton
              onPress={() => {
                if (gameState === 'PLAYING') setNextDirection('LEFT')
                else if (gameState === 'IDLE' || gameState === 'GAMEOVER') {
                  startGame()
                  nextDirectionRef.current = 'LEFT'
                  directionRef.current = 'LEFT'
                }
              }}
              label="左"
            >
              <ArrowLeft className="h-6 w-6" />
            </DPadButton>
            <DPadButton
              onPress={() => {
                if (gameState === 'PLAYING') setNextDirection('DOWN')
                else if (gameState === 'IDLE' || gameState === 'GAMEOVER') {
                  startGame()
                  nextDirectionRef.current = 'DOWN'
                  directionRef.current = 'DOWN'
                }
              }}
              label="下"
            >
              <ArrowDown className="h-6 w-6" />
            </DPadButton>
            <DPadButton
              onPress={() => {
                if (gameState === 'PLAYING') setNextDirection('RIGHT')
                else if (gameState === 'IDLE' || gameState === 'GAMEOVER') {
                  startGame()
                  nextDirectionRef.current = 'RIGHT'
                  directionRef.current = 'RIGHT'
                }
              }}
              label="右"
            >
              <ArrowRight className="h-6 w-6" />
            </DPadButton>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-auto pt-4 text-center text-xs text-slate-400">
          <p>方向键 / WASD 移动 · 空格暂停 · 不可反向撞自己</p>
        </footer>
      </div>
    </div>
  )
}

function DPadButton({
  children,
  onPress,
  label,
}: {
  children: React.ReactNode
  onPress: () => void
  label: string
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault()
        onPress()
      }}
      className="flex h-16 w-16 touch-none select-none items-center justify-center rounded-2xl bg-white text-emerald-600 shadow-md ring-1 ring-slate-200 active:bg-emerald-50 active:scale-95"
    >
      {children}
    </button>
  )
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.lineTo(x + w - radius, y)
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius)
  ctx.lineTo(x + w, y + h - radius)
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h)
  ctx.lineTo(x + radius, y + h)
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius)
  ctx.lineTo(x, y + radius)
  ctx.quadraticCurveTo(x, y, x + radius, y)
  ctx.closePath()
}
